=======================================
 RADOS Gateway developer documentation
=======================================

.. rubric:: Contents

.. toctree::
   :maxdepth: 1   
   
   
   usage
   Admin Ops Nonimplemented <admin/adminops_nonimplemented>
   s3_compliance
